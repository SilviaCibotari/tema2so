/************************************************************************/
#include <stdlib.h>
#include <string.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#include "so_stdio.h"
#define BUFLEN 4096
/*
 * Structura va contine file descriptorul, modul de accesare al acestuia,
 * doua buffer-e: ptr citire, respectiv scriere , cate un cursor pentru 
 * fiecare buffer, si o limita - lungimea buffer-ului la un moment anumit.
 * Deasemeni, am campurile eof si err, pentru monitorizarea erorilor
 * rezultate sau a sfarsitului de fisier.
 */
typedef struct _so_file {
	int permisions;
	int fd;

	char to_write[BUFLEN];
	char to_read[BUFLEN];

	int limit_w;
	int limit_r;

	int cursor_w;
	int cursor_r;

	int eof;
	int err;
} SO_FILE;

/*In functia get_mode intorc int-ul construit din drepturile de acces
 * (sau pe biti) in functie de tipul de acces primit ca parametru.
 */
FUNC_DECL_PREFIX int get_mode(const char *mode)
{
	int mode_int;

	if (!strcmp(mode, "r"))
		mode_int = O_RDONLY;
	else if (!strcmp(mode, "w"))
		mode_int = O_WRONLY | O_CREAT | O_TRUNC;
	else if (!strcmp(mode, "a"))
		mode_int = O_WRONLY | O_CREAT | O_APPEND;
	else if (!strcmp(mode, "r+"))
		mode_int = O_RDWR;
	else if (!strcmp(mode, "w+"))
		mode_int = O_RDWR | O_CREAT | O_TRUNC;
	else if (!strcmp(mode, "a+"))
		mode_int = O_RDWR | O_CREAT | O_APPEND;
	else
		mode_int = -1;

	return mode_int;
}
/* Creez structura aferenta fisierului si o initializez. Open deschide
 * sau creeaza un fisier.
 */
FUNC_DECL_PREFIX SO_FILE *so_fopen(const char *pathname, const char *mode)
{
	int modee = get_mode(mode);
	SO_FILE *file_struct;

	if (modee == -1)
		return NULL;
	file_struct = malloc(sizeof(SO_FILE));
	if (file_struct == NULL)
		return NULL;

	file_struct->fd = open(pathname, modee, 0621);
	if (file_struct->fd < 0) {
		free(file_struct);
		return NULL;
	}
	file_struct->permisions = modee;
	file_struct->limit_w = BUFLEN;
	file_struct->limit_r = 0;
	file_struct->cursor_w = 0;
	file_struct->cursor_r = 0;
	file_struct->eof = 0;
	file_struct->err = 0;
	return file_struct;

}
/*Functie pentru inchiderea fisierului + tratatre cazuri de eroare.
 */
FUNC_DECL_PREFIX int so_fclose(SO_FILE *stream)
{
	int res;

	if (so_fflush(stream) == SO_EOF && stream->cursor_w != 0) {
		free(stream);
		return SO_EOF;
	}
	res = close(stream->fd);
	free(stream);
	if (res < 0) {
		stream->err = 1;
		return SO_EOF;
	}
	return res;

}
/*Intoarce file descriptor-ul aferent structurii primita ca parametru.
 */
FUNC_DECL_PREFIX int so_fileno(SO_FILE *stream)
{
	return stream->fd;
}
/*Daca la momentul apelarii sunt careva date de scris in buffer-ul
 *stream->to_write, acestea sunt scrise in fisier. Avem date de scris
 daca cursorul in buffer e mai mare decat zero.
 */
FUNC_DECL_PREFIX int so_fflush(SO_FILE *stream)
{
	int res;

	if (stream->cursor_w == 0)
		return SO_EOF;
	res = write(stream->fd, stream->to_write, stream->cursor_w);
	if (res <= 0) {
		stream->err = 1;
		return SO_EOF;
	}
	stream->cursor_w = 0;
	return 0;
}
/*Functia muta cursorul in fisier la o pozitie relativa sau absoluta
 * folosind functia lseek.
 */
FUNC_DECL_PREFIX int so_fseek(SO_FILE *stream, long offset, int whence)
{
	long res;

	so_fflush(stream);
	stream->cursor_r = 0;
	stream->limit_r = 0;
	res = lseek(stream->fd, offset, whence);
	if (res < 0)
		return -1;
	return 0;
}
/*Intoarce pozitia curenta in fisier. Aceasta trebuie de modificat in functie
 * de valorile cursoarelor de sciere si citire intrucat se poate sa nu se fi
 * facut so_fflush sau sa se fi citit un bufer de caractere cu so_fgetc dintre
 * care doar cateva au trecut in so_fread. In acest caz, insa, cursorul nu sta
 * la pozitia corecta.
 */
FUNC_DECL_PREFIX long so_ftell(SO_FILE *stream)
{
	long res = lseek(stream->fd, 0, SEEK_CUR);

	if (res < 0)
		return -1;
	return res + stream->cursor_w - (stream->limit_r - stream->cursor_r);
}
/*Fuctia citeste nmemb elemente folosind so_fgetc.
 */
FUNC_DECL_PREFIX
size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	char aux[nmemb*size];
	int i = 0;
	int c;

	for (i = 0; i < nmemb; i++) {
		c = so_fgetc(stream);
		if (stream->err) {
			i = 0;
			break;
		}
		if (stream->eof)
			break;
		aux[i] = c;
	}
	memcpy(ptr, aux, i*size);
	return i;
}
/*Functia scrie nmemb elemente folosind so_fputc.
 */
FUNC_DECL_PREFIX
size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	char aux[nmemb];
	int i = 0;

	memcpy(aux, ptr, size*nmemb);
	for (i = 0; i < nmemb; i++)
		so_fputc(aux[i], stream);
	return nmemb;
}
/*Functia intoarce cate un caracter.
 * Mod de functionare: In cazul in care cursorul este egal cu limita, adica
 * ambele sunt zero - cazul intial, sau au fost intoarse toate caracterele din
 * buffer, se citeste un nou buffer. Procedez astfel pentru a reduce numarul
 * apelurilor de sistem. In cazul in care astea doua sunt diferita, intoarce
 * un element si avanseaza in buffer cu o pozitie.
 */
FUNC_DECL_PREFIX int so_fgetc(SO_FILE *stream)
{
	int res;

	if (stream->eof)
		return SO_EOF;

	if (stream->cursor_r == stream->limit_r) {
		res = read(stream->fd, stream->to_read, BUFLEN-1);
		if (res == 0) {
			stream->eof = 1;
			return SO_EOF;
		}
		if (res < 0) {
			stream->err = 1;
			return SO_EOF;
		}
		stream->to_read[res] = '\0';
		stream->limit_r = res;
		stream->cursor_r = 0;
	}
	return stream->to_read[stream->cursor_r++];
}
/*Modul ce operare la fel in ca in functia precedenta: pune cate un element in
 * buffer si face so_fflush doar cand buffer-ul s-a umplut de date, la fel
 * pentru a reduce numatul de apeluri de sistem.
 */
FUNC_DECL_PREFIX int so_fputc(int c, SO_FILE *stream)
{
	if (stream->cursor_w == stream->limit_w)
		if (so_fflush(stream) != 0)
			return SO_EOF;
	stream->to_write[stream->cursor_w++] = c;
	return c;

}

FUNC_DECL_PREFIX int so_feof(SO_FILE *stream)
{
	return stream->eof;
}
FUNC_DECL_PREFIX int so_ferror(SO_FILE *stream)
{
	return stream->err;
}

FUNC_DECL_PREFIX SO_FILE *so_popen(const char *command, const char *type)
{
	return NULL;
}
FUNC_DECL_PREFIX int so_pclose(SO_FILE *stream)
{
	return 0;
}
